if (document.getElementById("JoinUsText").clientHeight<=260) {document.getElementById("JoinUsHead").style.marginTop="2em";}
if (document.getElementById("NewsText").clientHeight<=260) {document.getElementById("NewsHead").style.marginTop="2em";}
if (document.getElementById("ForMoreText").clientHeight<=260) {document.getElementById("ForMoreHead").style.marginTop="2em";}
if (document.getElementById("WhereText").clientHeight<=260) {document.getElementById("WhereHead").style.marginTop="2em";}