<?php
$host="localhost";
$dbUsername="root";
$dbPassword="82468246a";
$dbname="Guild";
$conn=mysqli_connect($host,$dbUsername, $dbPassword,$dbname);
?>